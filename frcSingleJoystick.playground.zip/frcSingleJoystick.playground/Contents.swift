import UIKit


/* In java, and in the actual FRC code there is a function to pull the polar coordinates from joysticks in
 the code
 LINK: https://wpilib.screenstepslive.com/s/currentCS/m/java/l/599723-joysticks
 Able to get: Degrees, Radians, Magnitude
 POLAR COORDINATES

 This operates using degrees to change direction, and magnitude to change power
 For  quadrant 1 and 4, the left track will be at 100 and -100 respectively and will not change
 In Q1 and Q4 the only thing that will change the most is the right track
 
 for quadrant 2 and 3, the right track will be at 100 and -100 respectively and will not change
 in Q2 and Q3 the only thing that will change the most is the right track
 
*/

var degrees:Double = 0;
var magnitude:Double = 0;
// these will be the final outputs for the robot
var rightTrackSpeedBot:Double = 0
var leftTrackSpeedBot:Double = 0

//this functions is for the right wheels, for degrees between (not including) 0,90
func quadOneRightPower(degrees: Double) ->Double {

    var rightTrackSpeed:Double = 0
    
    if (degrees>=0 && degrees<=90) {
        rightTrackSpeed = degrees * (10/9)
    } else {
        print("ahh")
    }
    
    return rightTrackSpeed
}
//function for right wheels, for degrees between (not including) 270,360
func quadFourRightPower(degrees: Double) ->Double {
    var rightTrackSpeed:Double = 0
    
    if (degrees>=270 && degrees<360) {
        rightTrackSpeed = (100-( (degrees-270) * (10/9))) * -1
    } else {
      print("ahh V.2")
    }
    
    
    return rightTrackSpeed
    
    }

//function to change left wheels, for degrees between (not including) 90,180
func quadTwoLeftPower(degrees: Double) ->Double {
    
    var leftTrackSpeed:Double = 0
    
    if (degrees>90 && degrees<180) {
        
        leftTrackSpeed = 100 - (degrees-90) * (10/9)
        
    } else {
        print("ahh V.3")
    }
    
    
    return leftTrackSpeed
}

quadTwoLeftPower(degrees: 170)

//function to change left wheels, for degrees between (not including) 180, 270

func quadThreeLeftPower(degrees: Double) ->Double {
     var leftTrackSpeed:Double = 0
    if (degrees>180 && degrees<270) {
        leftTrackSpeed = ( (degrees-180) * (10/9)) * -1
    }
    
    return leftTrackSpeed
}

// Actual drive function using previous functions

func driveFunction(degrees: Double, magnitude : Double) ->String {
    // set axis degrees in regular coordinates, due to domain of functions
    if (degrees==0) {
        leftTrackSpeedBot = 100
        rightTrackSpeedBot = 0
    } else if (degrees==90){
        leftTrackSpeedBot = 100
        rightTrackSpeedBot = 100
    } else if (degrees == 180) {
        leftTrackSpeedBot = 0
        rightTrackSpeedBot == 100
    } else if (degrees == 270) {
        leftTrackSpeedBot == -100
        rightTrackSpeedBot == -100
        // follow domains of functions in if-else, use them while using remaining track power
    } else if (degrees>0 && degrees<90) {
    rightTrackSpeedBot = quadOneRightPower(degrees: degrees)
    leftTrackSpeedBot = 100
    } else if(degrees>90 && degrees<180){
    leftTrackSpeedBot = quadTwoLeftPower(degrees: degrees)
    rightTrackSpeedBot = 100
    } else if(degrees>180 && degrees<270) {
    leftTrackSpeedBot = quadThreeLeftPower(degrees: degrees)
    rightTrackSpeedBot = -100
    } else if(degrees>270 && degrees<360) {
    rightTrackSpeedBot = quadFourRightPower(degrees: degrees)
    leftTrackSpeedBot = -100
    } else {
        print("ahh v.4")
    }
    
    leftTrackSpeedBot = leftTrackSpeedBot * magnitude
    rightTrackSpeedBot  = rightTrackSpeedBot * magnitude
    
    return "\(leftTrackSpeedBot) is left, \(rightTrackSpeedBot) is right"
}

driveFunction(degrees: 222, magnitude: 0.5)




